package com.everis.fingerprints;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FingerPrintsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FingerPrintsApplication.class, args);
	}

}
