package com.everis.reniecs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReniecApplicationTests {

	@Test
	void contextLoads() {
	}

}
