INSERT INTO personas (document, fingerprint, blacklist) VALUES ('2563652312561478', true, true);
INSERT INTO personas (document, fingerprint, blacklist) VALUES ('7588985682451236', false, false);
INSERT INTO personas (document, fingerprint, blacklist) VALUES ('0211200879663895', false, true);