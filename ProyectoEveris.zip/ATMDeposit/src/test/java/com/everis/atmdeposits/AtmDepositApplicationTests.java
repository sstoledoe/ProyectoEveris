package com.everis.atmdeposits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtmDepositApplicationTests {

	@Test
	void contextLoads() {
	}

}
